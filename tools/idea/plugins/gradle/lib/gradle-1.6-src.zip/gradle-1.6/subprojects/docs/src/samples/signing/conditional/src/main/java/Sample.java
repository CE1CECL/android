class Sample {
}