package org.apache.maven.repository.metadata;

/*
 * Licensed to the Apache Software Foundation (ASF) under one
 * or more contributor license agreements.  See the NOTICE file
 * distributed with this work for additional information
 * regarding copyright ownership.  The ASF licenses this file
 * to you under the Apache License, Version 2.0 (the
 * "License"); you may not use this file except in compliance
 * with the License.  You may obtain a copy of the License at
 *
 *  http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing,
 * software distributed under the License is distributed on an
 * "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
 * KIND, either express or implied.  See the License for the
 * specific language governing permissions and limitations
 * under the License.
 */

/**
 *
 * @author <a href="mailto:oleg@codehaus.org">Oleg Gusakov</a>
 *
 * @version $Id: GraphConflictResolutionException.java 958295 2010-06-26 23:16:18Z hboutemy $
 */
public class GraphConflictResolutionException
    extends Exception
{
    private static final long serialVersionUID = 2677613140287940255L;

    public GraphConflictResolutionException()
    {
    }

    public GraphConflictResolutionException( String message )
    {
        super( message );
    }

    public GraphConflictResolutionException( Throwable cause )
    {
        super( cause );
    }

    public GraphConflictResolutionException( String message, Throwable cause )
    {
        super( message, cause );
    }

}
